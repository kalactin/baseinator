import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Table implements Comparable<Table> {
    String teamName;
    String division;
    public int wins;
    public int losses;
    public int rf;
    public int ra;
    public HashMap<String, Integer> recordAgainstOpponent;
    public HashMap<String, Integer> runDiffAgainstOpponent;
    public HashMap<String, Integer> raAgainstOpponent;
    public HashMap<String, Integer> rsAgainstOpponent;
    public ArrayList<String> tiebreakers;

    public Table(String teamName) {
        this.teamName = teamName;
        this.division = "";
        wins = 0;
        losses = 0;
        rf = 0;
        ra = 0;
        recordAgainstOpponent = new HashMap<>();
        runDiffAgainstOpponent = new HashMap<>();
        raAgainstOpponent = new HashMap<>();
        rsAgainstOpponent = new HashMap<>();
    }

    public Table(String teamName, String division) {
        this.teamName = teamName;
        this.division = division;
        wins = 0;
        losses = 0;
        rf = 0;
        ra = 0;
        recordAgainstOpponent = new HashMap<>();
        runDiffAgainstOpponent = new HashMap<>();
        raAgainstOpponent = new HashMap<>();
        rsAgainstOpponent = new HashMap<>();
    }

    public double getWinPct() {
        return (double)wins / (double)getGamesPlayed();
    }

    public int getRunDifferential() {
        return rf - ra;
    }

    public int getGamesPlayed() {
        return wins + losses;
    }

    private int randomTiebreak() {
        Random generator = new Random();
        if(generator.nextBoolean()) {
            return 1;
        }
        else {
            return -1;
        }
    }

    public int compareTo(Table other) {
        if(this.wins > other.wins) {
            return -1;
        }
        else if(other.wins > this.wins) {
            return 1;
        }
        else {
            if(tiebreakers == null) {
                return randomTiebreak();
            }
            int tiebreakerNum = 0;
            while(true) {
                if(tiebreakerNum == tiebreakers.size()) {
                    return randomTiebreak();
                }
                else if(tiebreakers.get(tiebreakerNum).equals("HTHRec")) {
                    if(recordAgainstOpponent.containsKey(other.teamName) && recordAgainstOpponent.get(other.teamName) != 0) {
                        return recordAgainstOpponent.get(other.teamName) * -1;
                    }
                }
                else if(tiebreakers.get(tiebreakerNum).equals("HTHRunDiff")) {
                    if(runDiffAgainstOpponent.containsKey(other.teamName) && runDiffAgainstOpponent.get(other.teamName) != 0) {
                        return runDiffAgainstOpponent.get(other.teamName) * -1;
                    }
                }
                else if(tiebreakers.get(tiebreakerNum).equals("HTHRunsFor")) {
                    if(rsAgainstOpponent.containsKey(other.teamName) && other.rsAgainstOpponent.containsKey(teamName) && rsAgainstOpponent.get(other.teamName) != other.rsAgainstOpponent.get(teamName)) {
                        return other.rsAgainstOpponent.get(teamName) - rsAgainstOpponent.get(other.teamName);
                    }
                }
                else if(tiebreakers.get(tiebreakerNum).equals("HTHRunsAgainst")) {
                    if(raAgainstOpponent.containsKey(other.teamName) && other.raAgainstOpponent.containsKey(teamName)&& raAgainstOpponent.get(other.teamName) != other.raAgainstOpponent.get(teamName)) {
                        return raAgainstOpponent.get(other.teamName) - other.raAgainstOpponent.get(teamName);
                    }
                }
                else if(tiebreakers.get(tiebreakerNum).equals("RunDiff")) {
                    int otherRunDiff = other.getRunDifferential();
                    int runDiff = getRunDifferential();
                    if(otherRunDiff != runDiff) {
                        return otherRunDiff - runDiff;
                    }
                }
                else if(tiebreakers.get(tiebreakerNum).equals("RunsFor")) {
                    if(other.rf != rf) {
                        return other.rf - rf;
                    }
                }
                else if(tiebreakers.get(tiebreakerNum).equals("RunsAgainst")) {
                    if(other.ra != ra) {
                        return ra - other.ra;
                    }
                }
                tiebreakerNum++;
            }
        }
    }
}