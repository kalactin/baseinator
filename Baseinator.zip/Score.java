public class Score {
    public String homeTeam;
    public String awayTeam;
    public String division;
    public int homeScore;
    public int awayScore;

    public Score(String homeTeam, String awayTeam, int homeScore, int awayScore) {
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.homeScore = homeScore;
        this.awayScore = awayScore;
    }

    public Score(String homeTeam, String awayTeam, int homeScore, int awayScore, String division) {
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.homeScore = homeScore;
        this.awayScore = awayScore;
        this.division = division;
    }

    public String toString() {
        return homeTeam + " " + homeScore + "-" + awayScore + " " + awayTeam;
    }
}