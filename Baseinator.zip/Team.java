public class Team {
    public int teamID;
    public String name;
    public String trigram;
    public double skill;
    public double style;
    public double parkFactor;
    public int score[];
    public int numInnings;
    public boolean homeBatsInLastInning;
    public String division;
    private static int nextID = 0;

    public Team(String name, String trigram, double skill, double style, double parkFactor, int numInnings, String division) {
        if(style > 5.00) {
            style = 5.00;
        }
        else if(style < -5.00) {
            style = -5.00;
        }
        if(parkFactor > 200.00) {
            parkFactor = 200.00;
        }
        else if(parkFactor < 50.00) {
            parkFactor = 50.00;
        }
        this.name = name;
        this.trigram = trigram;
        this.skill = skill;
        this.style = style;
        this.parkFactor = parkFactor;
        this.score = new int[numInnings];
        this.teamID = nextID;
        this.numInnings = numInnings;
        this.division = division;
        homeBatsInLastInning = true;
        nextID++;
    }

    public void addInnings() {
        int temp[] = new int[score.length * 2];
        for(int i = 0; i < score.length; i++) {
            temp[i] = score[i];
        }
        score = temp;
    }

    public int getTotalScore() {
        int sum = 0;
        for(int i = 0; i < score.length; i++) {
            sum += score[i];
        }
        return sum;
    }

    public void resetScore(int numInnings) {
        score = new int[numInnings];
        this.numInnings = numInnings;
        homeBatsInLastInning = true;
    }

    public void applyBonus(Bonus bonus) {
        if(bonus.trigram.toUpperCase().equals(this.trigram.toUpperCase())) {
            this.skill += bonus.skill;
        }
    }
}

class Bonus {
    public String trigram;
    public double skill;

    public Bonus(String trigram, double skill) {
        this.trigram = trigram;
        this.skill = skill;
    }
}