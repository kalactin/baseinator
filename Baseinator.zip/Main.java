import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static Const constants = getConstants();
    public static void main(String[] args) {
        ArrayList<Team> teams = getTeams();
        Scanner readInput = new Scanner(System.in);
        System.out.println("Baseinator Version 1.3.1");
        System.out.println(teams.size() + " teams loaded.");
        if(teams.size() < 2) {
            System.err.println("You must enter at least 2 teams to scorinate a game.");
            System.exit(-1);
        }
        while(true) {
            System.out.println("1) Scorinate Single Gameday");
            System.out.println("2) Scorinate Home and Away");
            System.out.println("3) Scorinate 2 Game Series");
            System.out.println("4) Scorinate 3 Game Series");
            System.out.println("5) Scorinate X Home and Away Series");
            System.out.println("6) Scorinate X Game Series");
            System.out.println("7) Scorinate X Round Robins");
            System.out.println("8) Scorinate a Single Matchday of a Round Robin");
            System.out.println("9) Generate Tables");
            System.out.println("A) Scorinate X Home then Away Series");
            //System.out.println("8) Adjust Constants");
            //System.out.println("9) Adjust Teams");
            System.out.println("0) Quit");
            System.out.println("Enter your choice: ");
            String choice = readInput.nextLine();
            switch (choice) {
                case "1":
                    scorinateGameday(teams, 1, false, true);
                    break;
                case "2":
                    scorinateGameday(teams, 1, true, true);
                    break;
                case "3":
                    scorinateGameday(teams, 2, false, true);
                    break;
                case "4":
                    scorinateGameday(teams, 3, false, true);
                    break;
                case "5":
                    try {
                        System.out.println("How many home and away games do you want to scorinate?");
                        int numGames = Integer.valueOf(readInput.nextLine());
                        scorinateGameday(teams, numGames, true, true);
                    }catch (Exception e) {
                        System.err.println("Invalid input.");
                    }
                    break;
                case "6":
                    try {
                        System.out.println("How long is the series you want to scorinate?");
                        scorinateGameday(teams, Integer.valueOf(readInput.nextLine()), false, true);
                    }catch (Exception e) {
                        System.err.println("Invalid input.");
                    }
                    break;
                case "7":
                    try {
                        System.out.println("How long will a series be in the Round Robin(s) you want to scorinate?");
                        int seriesLength = Integer.valueOf(readInput.nextLine());
                        while (seriesLength < 1) {
                            System.out.println("Invalid length. You must enter a length of at least 1");
                            seriesLength = Integer.valueOf(readInput.nextLine());
                        }
                        System.out.println("Each team will play " + seriesLength + " games against each divisional opponent per Round Robin");
                        System.out.println("How many Round Robins do you want to scorinate");
                        scorinateRoundRobin(teams, Integer.valueOf(readInput.nextLine()), seriesLength);
                    }catch (Exception e) {
                        System.err.println("Invalid input.");
                    }
                    break;
                case "8":
                    try {
                        System.out.println("How long is a series in this Round Robin?");
                        int seriesLength = Integer.valueOf(readInput.nextLine());
                        while (seriesLength < 1) {
                            System.out.println("Invalid length. You must enter a length of at least 1");
                            seriesLength = Integer.valueOf(readInput.nextLine());
                        }
                        System.out.println("What matchday of the Round Robin do you want to scorinate?");
                        scorinateRoundRobinMatchday(teams, seriesLength, Integer.valueOf(readInput.nextLine()) - 1);
                    }catch (Exception e) {
                        System.err.println("Invalid input.");
                    }
                    break;
                case "9":
                    generateTables();
                    break;
                case "A":
                case "a":
                    try {
                        System.out.println("How many home and away games do you want to scorinate?");
                        int numGames = Integer.valueOf(readInput.nextLine());
                        scorinateGameday(teams, numGames, true, false);
                    }catch (Exception e) {
                        System.err.println("Invalid input.");
                    }
                    break;
                /*case "8":
                    adjustConstants();
                    break;
                case "9":
                    teams = adjustTeams(teams);
                    break;*/
                case "0":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Enter the number corresponding to your choice.");
                    break;
            }
        }
    }

    // Begin Table Generator Code

    private static void generateTables() {
        ArrayList<String> tiebreakers = getTiebreakers();
        ArrayList<Score> scores = getScores();
        //ArrayList<Table> tables = getTables(scores, tiebreakers);
        ArrayList<ArrayList<Table>> divisions = getTableDivisions(getTables(scores, tiebreakers));
        PrintWriter output = null;
        if(divisions.size() > 0) {
            try {
                output = new PrintWriter((new FileOutputStream("tables.txt", true)));
                output.println("-----------------------------------------------------------------------------------------\n");
                for (ArrayList<Table> tables : divisions) {
                    Collections.sort(tables);
                    output.println();
                    if(divisions.size() != 1) {
                        output.println(tables.get(0).division);
                    }
                    int maxNameLength = 0;
                    int maxWins = 0;
                    int maxLosses = 0;
                    int maxGamesPlayed = 0;
                    int maxRF = 0;
                    int maxRA = 0;
                    int maxRD = 0;
                    for (Table t : tables) {
                        if (t.teamName.length() > maxNameLength) {
                            maxNameLength = t.teamName.length();
                        }
                        if (t.wins > maxWins) {
                            maxWins = t.wins;
                        }
                        if (t.losses > maxLosses) {
                            maxLosses = t.losses;
                        }
                        if (t.getGamesPlayed() > maxGamesPlayed) {
                            maxGamesPlayed = t.getGamesPlayed();
                        }
                        if (t.rf > maxRF) {
                            maxRF = t.rf;
                        }
                        if (t.ra > maxRA) {
                            maxRA = t.ra;
                        }
                        if (Math.abs(t.getRunDifferential()) > maxRD) {
                            maxRD = Math.abs(t.getRunDifferential());
                        }
                    }
                    if (maxGamesPlayed > 0) {
                        int numTeams = numDigits(tables.size());
                        maxWins = numDigits(maxWins);
                        maxLosses = numDigits(maxLosses);
                        maxGamesPlayed = numDigits(maxGamesPlayed);
                        maxRF = numDigits(maxRF);
                        maxRA = numDigits(maxRA);
                        maxRD = numDigits(maxRD);
                        String header = "";
                        for (int i = 0; i < numTeams; i++) {
                            header += " ";
                        }
                        header += " ";
                        for (int i = 0; i < maxNameLength; i++) {
                            header += " ";
                        }
                        header += " ";
                        for (int i = 0; i < maxGamesPlayed - 1; i++) {
                            header += " ";
                        }
                        header += "G ";
                        for (int i = 0; i < maxWins - 1; i++) {
                            header += " ";
                        }
                        header += "W ";
                        for (int i = 0; i < maxLosses - 1; i++) {
                            header += " ";
                        }
                        header += "L ";
                        for (int i = 0; i < maxRF - 2; i++) {
                            header += " ";
                        }
                        header += "RF ";
                        for (int i = 0; i < maxRA - 2; i++) {
                            header += " ";
                        }
                        header += "RA ";
                        for (int i = 0; i < maxRD - 1; i++) {
                            header += " ";
                        }
                        header += "RD ";
                        header += "Win Pct.";
                        output.println(header);
                        if (maxRA < 2) {
                            maxRA = 2;
                        }
                        if (maxRF < 2) {
                            maxRF = 2;
                        }
                        if (maxRD < 2) {
                            maxRD = 2;
                        }
                        for (int i = 0; i < tables.size(); i++) {
                            Table t = tables.get(i);
                            String table = "";
                            for (int j = 0; j < numTeams - numDigits(i + 1); j++) {
                                table += " ";
                            }
                            table += (i + 1) + " ";
                            for (int j = 0; j < maxNameLength - t.teamName.length(); j++) {
                                table += " ";
                            }
                            table += t.teamName + " ";
                            for (int j = 0; j < maxGamesPlayed - numDigits(t.getGamesPlayed()); j++) {
                                table += " ";
                            }
                            table += t.getGamesPlayed() + " ";
                            for (int j = 0; j < maxWins - Math.max(numDigits(t.wins), 1); j++) {
                                table += " ";
                            }
                            table += t.wins + " ";
                            for (int j = 0; j < maxLosses - Math.max(numDigits(t.losses), 1); j++) {
                                table += " ";
                            }
                            table += t.losses + " ";
                            for (int j = 0; j < maxRF - Math.max(numDigits(t.rf), 1); j++) {
                                table += " ";
                            }
                            table += t.rf + " ";
                            for (int j = 0; j < maxRA - Math.max(numDigits(t.ra), 1); j++) {
                                table += " ";
                            }
                            table += t.ra + " ";
                            if (t.getRunDifferential() < 0) {
                                for (int j = 0; j < maxRD - Math.max(numDigits(t.getRunDifferential()), 1); j++) {
                                    table += " ";
                                }
                                table += t.getRunDifferential() + " ";
                            } else {
                                for (int j = 0; j < maxRD - Math.max(numDigits(t.getRunDifferential()), 1); j++) {
                                    table += " ";
                                }
                                table += "+" + t.getRunDifferential() + " ";
                            }
                            table += String.format("%.3f", t.getWinPct());
                            output.println(table);
                        }
                    }
                }
            } catch (FileNotFoundException e) {

            } finally {
                output.close();
            }
        }
    }

    public static ArrayList<ArrayList<Table>> getTableDivisions(ArrayList<Table> tables) {
        ArrayList<ArrayList<Table>> divisions = new ArrayList<>();
        String currentDivisionName = tables.get(0).division;
        ArrayList<Table> currentDivision = new ArrayList<>();
        for(int i = 0; i < tables.size(); i++) {
            Table currentTable = tables.get(i);
            if(!currentTable.division.equals(currentDivisionName)) {
                divisions.add(currentDivision);
                currentDivision = new ArrayList<>();
                currentDivisionName = currentTable.division;
            }
            currentDivision.add(currentTable);
        }
        divisions.add(currentDivision);
        return divisions;
    }

    public static int numDigits(int number) {
        int digits = 0;
        while(number != 0) {
            number = number / 10;
            digits++;
        }
        return digits;
    }

    private static ArrayList<String> getTiebreakers() {
        Scanner tiebreakReader;
        ArrayList<String> tiebreakers = new ArrayList<>();
        try {
            tiebreakReader = new Scanner(new FileReader("tiebreakers.txt"));
            while(tiebreakReader.hasNextLine()) {
                String tiebreak = tiebreakReader.nextLine();
                tiebreakers.add(tiebreak);
            }
        }catch (Exception e) {
            System.err.println("No tiebreakers.txt file found");
        }finally {
            return tiebreakers;
        }
    }

    public static ArrayList<Score> getScores() {
        ArrayList<Score> scores = new ArrayList<>();
        Pattern scorePattern = Pattern.compile("\\d+\\Q-\\E\\d+");
        Pattern scorePattern2 = Pattern.compile("\\d+\\Q–\\E\\d+");
        Scanner scoreReader = null;
        String currentDivision = "";
        try{
            scoreReader = new Scanner(new FileReader("results.txt"));
            while(scoreReader.hasNextLine()) {
                String line = scoreReader.nextLine();
                Matcher matcher = scorePattern.matcher(line);
                Matcher matcher2 = scorePattern2.matcher(line);
                if(matcher.find()) {
                    String scoreString = matcher.group();
                    String homeTeam = line.substring(0, matcher.start() - 1);
                    String awayTeam = line.substring(matcher.end() + 1);
                    int homeScore = Integer.valueOf(scoreString.substring(0, scoreString.indexOf("-")));
                    int awayScore = Integer.valueOf(scoreString.substring(scoreString.indexOf("-") + 1));
                    Score score = new Score(homeTeam, awayTeam, homeScore, awayScore, currentDivision);
                    scores.add(score);
                }
                else if(matcher2.find()) {
                    String scoreString = matcher2.group();
                    String homeTeam = line.substring(0, matcher2.start() - 1);
                    String awayTeam = line.substring(matcher2.end() + 1);
                    int homeScore = Integer.valueOf(scoreString.substring(0, scoreString.indexOf("–")));
                    int awayScore = Integer.valueOf(scoreString.substring(scoreString.indexOf("–") + 1));
                    Score score = new Score(homeTeam, awayTeam, homeScore, awayScore, currentDivision);
                    scores.add(score);
                }
                else {
                    if(!line.equals("")) {
                        currentDivision = line;
                    }
                    //System.out.println(line);
                }
            }
        }catch(FileNotFoundException fnfe) {
            System.err.println("results.txt not found");
        }finally{
            scoreReader.close();
        }
        return scores;
    }

    public static ArrayList<Table> getTables(ArrayList<Score> scores, ArrayList<String> tiebreakers) {
        ArrayList<Table> tables = new ArrayList<>();
        // Generate tables
        for(Score s: scores) {
            Table home = null;
            Table away = null;
            for(Table t: tables) {
                if(home != null && away != null) {
                    break;
                }
                if(t.teamName.equals(s.homeTeam) && s.division.equals(t.division)) {
                    home = t;
                }
                if(t.teamName.equals(s.awayTeam) && s.division.equals(t.division)) {
                    away = t;
                }
            }
            if(home == null) {
                home = new Table(s.homeTeam, s.division);
                home.tiebreakers = tiebreakers;
                tables.add(home);
            }
            if(away == null) {
                away = new Table(s.awayTeam, s.division);
                away.tiebreakers = tiebreakers;
                tables.add(away);
            }
            home.rf += s.homeScore;
            home.ra += s.awayScore;
            away.rf += s.awayScore;
            away.ra += s.homeScore;
            int margin = Math.abs(s.homeScore - s.awayScore);
            if(home.rsAgainstOpponent.containsKey(away.teamName)) {
                home.rsAgainstOpponent.put(away.teamName, home.rsAgainstOpponent.get(away.teamName) + s.homeScore);
                home.raAgainstOpponent.put(away.teamName, home.raAgainstOpponent.get(away.teamName) + s.awayScore);
                away.rsAgainstOpponent.put(home.teamName, away.rsAgainstOpponent.get(home.teamName) + s.awayScore);
                away.raAgainstOpponent.put(home.teamName, away.raAgainstOpponent.get(home.teamName) + s.homeScore);
            }
            else {
                home.rsAgainstOpponent.put(away.teamName, s.homeScore);
                home.raAgainstOpponent.put(away.teamName, s.awayScore);
                away.rsAgainstOpponent.put(home.teamName, s.awayScore);
                away.raAgainstOpponent.put(home.teamName, s.homeScore);
            }
            if(s.homeScore == s.awayScore) {
            }else if(s.homeScore > s.awayScore) {
                home.wins++;
                away.losses++;
                if(home.runDiffAgainstOpponent.containsKey(away.teamName)) {
                    home.runDiffAgainstOpponent.put(away.teamName, home.runDiffAgainstOpponent.get(away.teamName) + margin);
                    home.recordAgainstOpponent.put(away.teamName, home.recordAgainstOpponent.get(away.teamName) + 1);
                    away.runDiffAgainstOpponent.put(home.teamName, away.runDiffAgainstOpponent.get(home.teamName) - margin);
                    away.recordAgainstOpponent.put(home.teamName, away.recordAgainstOpponent.get(home.teamName) - 1);
                }
                else {
                    home.runDiffAgainstOpponent.put(away.teamName, margin);
                    home.recordAgainstOpponent.put(away.teamName, 1);
                    away.recordAgainstOpponent.put(home.teamName, -1);
                    away.runDiffAgainstOpponent.put(home.teamName, margin * (-1));
                }
            }else {
                away.wins++;
                home.losses++;
                if(home.runDiffAgainstOpponent.containsKey(away.teamName)) {
                    home.runDiffAgainstOpponent.put(away.teamName, home.runDiffAgainstOpponent.get(away.teamName) - margin);
                    home.recordAgainstOpponent.put(away.teamName, home.recordAgainstOpponent.get(away.teamName) - 1);
                    away.runDiffAgainstOpponent.put(home.teamName, away.runDiffAgainstOpponent.get(home.teamName) + margin);
                    away.recordAgainstOpponent.put(home.teamName, away.recordAgainstOpponent.get(home.teamName) + 1);
                }
                else {
                    home.runDiffAgainstOpponent.put(away.teamName, margin * (-1));
                    home.recordAgainstOpponent.put(away.teamName, -1);
                    away.recordAgainstOpponent.put(home.teamName, 1);
                    away.runDiffAgainstOpponent.put(home.teamName, margin);
                }
            }
        }
        return tables;
    }


    // End Table Generator Code

    private static Const getConstants() {
        Scanner constantsReader;
        Const constants = null;
        try {
            constantsReader = new Scanner(new FileReader("constants.txt"));
            if(constantsReader.hasNextDouble()) {
                double runsConst = constantsReader.nextDouble();
                if(constantsReader.hasNextDouble()) {
                    double lnmax = constantsReader.nextDouble();
                    if(constantsReader.hasNextDouble()) {
                        double maxRunVariance = constantsReader.nextDouble();
                        if(constantsReader.hasNextInt()) {
                            int maxStyleChange = constantsReader.nextInt();
                            if(constantsReader.hasNextDouble()) {
                                double styleMultiplier = constantsReader.nextDouble();
                                if(constantsReader.hasNextDouble()) {
                                    double parkFactorMultiplier = constantsReader.nextDouble();
                                    if(constantsReader.hasNextDouble()) {
                                        double extraInningRunsConst = constantsReader.nextDouble();
                                        if (constantsReader.hasNextInt()) {
                                            int numInnings = constantsReader.nextInt();
                                            if (constantsReader.hasNextDouble()) {
                                                double homeFieldAdvantage = constantsReader.nextDouble();
                                                constants = new Const(runsConst, lnmax, maxRunVariance, maxStyleChange, styleMultiplier, parkFactorMultiplier, extraInningRunsConst, numInnings, homeFieldAdvantage);
                                            }
                                            else {
                                                constants = new Const(runsConst, lnmax, maxRunVariance, maxStyleChange, styleMultiplier, parkFactorMultiplier, extraInningRunsConst, numInnings, 0.005);
                                            }
                                        }
                                        else {
                                            constants = new Const(runsConst, lnmax, maxRunVariance, maxStyleChange, styleMultiplier, parkFactorMultiplier, extraInningRunsConst, 9, 0.005);
                                        }
                                    }
                                    else {
                                        constants = new Const(runsConst, lnmax, maxRunVariance, maxStyleChange, styleMultiplier, parkFactorMultiplier, -1, 9, 0.005);
                                    }
                                }
                                else {
                                    constants = new Const(runsConst, lnmax, maxRunVariance, maxStyleChange, styleMultiplier, 0.2, -1, 9, 0.005);
                                }
                            }
                            else {
                                constants = new Const(runsConst, lnmax, maxRunVariance, maxStyleChange, 0.5, 0.2, -1, 9, 0.005);
                            }
                        }
                        else {
                            constants = new Const(runsConst, lnmax, maxRunVariance, 6, 0.5, 0.2, -1, 9, 0.005);
                        }
                    }
                    else {
                        constants = new Const(runsConst, lnmax, 0.1, 6, 0.5, 0.2, -1, 9, 0.005);
                    }
                }
                else {
                    constants = new Const(runsConst, 5, 0.1, 6, 0.5, 0.2, -1, 9, 0.005);
                }
            }
            else {
                constants = new Const();
            }
        } catch(Exception e) {
            System.err.println("No constants.txt file found");
            constants = new Const();
        }
        return  constants;
    }

    private static ArrayList<Team> getTeams() {
        ArrayList<Team> teams = new ArrayList<>();
        Scanner teamReader;
        Pattern divisionPattern = Pattern.compile("[\\w \\W]*:$");
        String division = "";
        try {
            teamReader = new Scanner(new FileReader("teams.txt"));
            while (teamReader.hasNextLine()) {
                String temp = teamReader.nextLine();
                Matcher matcher = divisionPattern.matcher(temp);
                if(matcher.matches()) {
                    division = temp.substring(0, temp.length() - 1);
                }
                else {
                    int cut = temp.indexOf(';');
                    if (cut != -1) {
                        String name = temp.substring(0, cut);
                        temp = temp.substring(cut + 1);
                        cut = temp.indexOf(';');
                        if (cut != -1) {
                            String trigram = temp.substring(0, cut);
                            temp = temp.substring(cut + 1);
                            cut = temp.indexOf(';');
                            if (cut != -1) {
                                double skill;
                                try {
                                    skill = Double.valueOf(temp.substring(0, cut));
                                    temp = temp.substring(cut + 1);
                                    cut = temp.indexOf(';');
                                } catch (NumberFormatException nfe) {
                                    System.err.println(name + " has an invalid skill modifier. Not added.");
                                    continue;
                                }
                                if (cut != -1) {
                                    double style;
                                    try {
                                        style = Double.valueOf(temp.substring(0, cut));
                                        temp = temp.substring(cut + 1);
                                    } catch (NumberFormatException nfe) {
                                        teams.add(new Team(name, trigram, skill, 0, 100, constants.numInnings, division));
                                        continue;
                                    }
                                    try {
                                        double parkFactor = Double.valueOf(temp);
                                        teams.add(new Team(name, trigram, skill, style, parkFactor, constants.numInnings, division));
                                    } catch (NumberFormatException nfe) {
                                        teams.add(new Team(name, trigram, skill, style, 100, constants.numInnings, division));
                                    }
                                } else {
                                    try {
                                        double style = Double.valueOf(temp);
                                        teams.add(new Team(name, trigram, skill, style, 100, constants.numInnings, division));
                                    } catch (NumberFormatException nfe) {
                                        teams.add(new Team(name, trigram, skill, 0, 100, constants.numInnings, division));
                                    }
                                }
                            } else {
                                try {
                                    double skill = Double.valueOf(temp);
                                    teams.add(new Team(name, trigram, skill, 0, 100, constants.numInnings, division));
                                } catch (NumberFormatException nfe) {
                                    System.err.println(name + " has an invalid skill modifier. Not added.");
                                }
                            }
                        }
                    }
                }
            }
            teamReader.close();
            Scanner bonusReader;
            try {
                bonusReader = new Scanner(new FileReader("bonus.txt"));
                while (bonusReader.hasNextLine()) {
                    String temp = bonusReader.nextLine();
                    int cut = temp.indexOf(';');
                    if(cut == -1) {
                        continue;
                    }
                    try {
                        Bonus bonus = new Bonus(temp.substring(0, cut), Double.valueOf(temp.substring(cut + 1)));
                        for (Team t: teams) {
                            // applyBonus method only applies bonus if trigrams are the same, ignoring case.
                            t.applyBonus(bonus);
                        }
                    } catch (NumberFormatException nfe) {
                        System.err.println("line containing \"" + temp + "\" in bonus.txt file is not formatted correctly");
                        continue;
                    }
                }
            } catch(Exception e) {
                System.err.println("No bonus.txt file found.");
            }
            return teams;
        }catch(Exception e) {
            System.err.println("No teams.txt file found.");
            return teams;
        }
    }

    private static ArrayList<Team> adjustTeams(ArrayList<Team> teams) {
        return teams;
    }

    /*private static void adjustConstants() {
        while(true) {
            return;
        }
    }*/

    private static void scorinate(Team road, Team home) {
        // Replace Negative Skill Values with zero
        if (road.skill < 0.0) {
            road.skill = 0.0;
        }
        if (home.skill < 0.0) {
            home.skill = 0.0;
        }
        // Determine the ratios
        double ratioRoad = road.skill - home.skill;
        double ratioHome;
        if ((ratioRoad >= 0.0 && ratioRoad < 0.001) || (ratioRoad <= -0.0 && ratioRoad > -0.001)) {
            ratioRoad = -0.1;
            ratioHome = -0.1;
        } else if (road.skill < 0.001) {
            ratioRoad = -1.0;
            ratioHome = -1.0;
        } else if (home.skill < 0.001) {
            ratioRoad = -2.0;
            ratioHome = -2.0;
        } else {
            ratioRoad = road.skill / home.skill;
            ratioHome = home.skill / road.skill;
        }
        // Determine each team's runs per inning
        double roadTeamRunsConst = constants.runsConst;
        double homeTeamRunsConst = constants.runsConst;
        if(ratioRoad >= 0.0 && ratioHome > ratioRoad) {
            // Home team is better, both non-zero skills
            double multiplier = Math.log(ratioHome * Math.exp(1)) / constants.lnmax;
            if(multiplier > 1.0) {
                multiplier = 1.0;
            }
            homeTeamRunsConst += multiplier * constants.maxRunVariance;
            roadTeamRunsConst -= multiplier * constants.maxRunVariance;
        }
        else if(ratioRoad >= 0) {
            // Road team is better, both non-zero skills.
            double multiplier = Math.log(ratioRoad * Math.exp(1)) / constants.lnmax;
            if(multiplier > 1.0) {
                multiplier = 1.0;
            }
            roadTeamRunsConst += multiplier * constants.maxRunVariance;
            homeTeamRunsConst -= multiplier * constants.maxRunVariance;
        }
        else if(ratioRoad < -1.7) {
            // Home skill is zero, road skill is non-zero
            roadTeamRunsConst += constants.maxRunVariance;
            homeTeamRunsConst -= constants.maxRunVariance;
        }
        else if(ratioRoad < -0.7) {
            // Road skill is zero, home skill is non-zero
            homeTeamRunsConst += constants.maxRunVariance;
            roadTeamRunsConst -= constants.maxRunVariance;
        }
        else {
            // Home and road skill is equal, so do nothing.
        }
        // Apply home field advantage
        homeTeamRunsConst += constants.homeFieldAdvantage;
        roadTeamRunsConst -= constants.homeFieldAdvantage;

        // Determine each team's out probability.
        double homeOutProb = determineOutProbability(homeTeamRunsConst);
        double roadOutProb = determineOutProbability(roadTeamRunsConst);

        Random generator = new Random();

        // Scorinate regulation innings
        for(int i = 0; i < constants.numInnings; i++) {
            for(int j = 0; j < 2; j++) {
                if(j == 1 && i == constants.numInnings - 1 && home.getTotalScore() > road.getTotalScore()) {
                    home.homeBatsInLastInning = false;
                    break;
                }
                boolean out = false;
                while(!out) {
                    if(j == 1 && i == constants.numInnings - 1) {
                        int scoreDif = home.getTotalScore() - road.getTotalScore();
                        if(scoreDif == 4) {
                            break;
                        }
                    }
                    double rng = generator.nextDouble();
                    if (j == 0) {
                        if(rng > roadOutProb) {
                            road.score[i]++;
                        }
                        else {
                            out = true;
                        }
                    }
                    else {
                        if(rng > homeOutProb) {
                            home.score[i]++;
                        }
                        else {
                            out = true;
                        }
                    }
                }
            }
        }

        // Extra Innings (if needed)
        if(home.getTotalScore() == road.getTotalScore()) {
            // Check if extraInningRunsConst is used
            if(constants.extraInningRunsConst > 0.0) {
                // Determine each team's runs per inning
                roadTeamRunsConst = constants.extraInningRunsConst;
                homeTeamRunsConst = constants.extraInningRunsConst;
                if(ratioRoad >= 0.0 && ratioHome > ratioRoad) {
                    // Home team is better, both non-zero skills
                    double multiplier = Math.log(ratioHome * Math.exp(1)) / constants.lnmax;
                    if(multiplier > 1.0) {
                        multiplier = 1.0;
                    }
                    homeTeamRunsConst += multiplier * constants.maxRunVariance;
                    roadTeamRunsConst -= multiplier * constants.maxRunVariance;
                }
                else if(ratioRoad >= 0) {
                    // Road team is better, both non-zero skills.
                    double multiplier = Math.log(ratioRoad * Math.exp(1)) / constants.lnmax;
                    if(multiplier > 1.0) {
                        multiplier = 1.0;
                    }
                    roadTeamRunsConst += multiplier * constants.maxRunVariance;
                    homeTeamRunsConst -= multiplier * constants.maxRunVariance;
                }
                else if(ratioRoad < -1.7) {
                    // Home skill is zero, road skill is non-zero
                    roadTeamRunsConst += constants.maxRunVariance;
                    homeTeamRunsConst -= constants.maxRunVariance;
                }
                else if(ratioRoad < -0.7) {
                    // Road skill is zero, home skill is non-zero
                    homeTeamRunsConst += constants.maxRunVariance;
                    roadTeamRunsConst -= constants.maxRunVariance;
                }
                else {
                    // Home and road skill is equal, so do nothing.
                }

                // Determine each team's out probability.
                homeOutProb = determineOutProbability(homeTeamRunsConst);
                roadOutProb = determineOutProbability(roadTeamRunsConst);
            }
            int curInn = constants.numInnings - 1;
            boolean tied = true;
            int scoreDif = 0;
            while(scoreDif == 0) {
                curInn++;
                home.numInnings++;
                road.numInnings++;
                if(curInn == road.score.length) {
                    road.addInnings();
                    home.addInnings();
                }
                for(int j = 0; j < 2; j++) {
                    boolean out = false;
                    while(!out) {
                        if(scoreDif == 4) {
                            break;
                        }
                        double rng = generator.nextDouble();
                        if(j == 0) {
                            if(rng > roadOutProb) {
                                road.score[curInn]++;
                                scoreDif--;
                            }
                            else {
                                out = true;
                            }
                        }
                        else {
                            if(rng > homeOutProb) {
                                home.score[curInn]++;
                                scoreDif++;
                            }
                            else {
                                out = true;
                            }
                        }
                    }
                }
            }
        }
        // Apply style modifiers
        double styleSum = road.style + home.style;
        int maxChange = constants.maxStyleChange;
        styleSum += 10.0;
        styleSum = styleSum / 20.0;
        boolean increase = false;
        // Determine if runs will be added or removed
        if(generator.nextDouble() < styleSum) {
            increase = true;
        }
        if(!increase) {
            // Ensure that style mods cannot change margin of victory
            maxChange = Math.min(maxChange, Math.min(road.getTotalScore(), home.getTotalScore()));
        }
        int totalChange = 0;
        // Apply Style Multiplier and Park Factor effect then calculate number of runs to change.
        styleSum = styleSum * 20;
        styleSum -= 10;
        styleSum = styleSum * constants.styleMultiplier;
        double parkFactorEffect = home.parkFactor / 100.0;
        parkFactorEffect -= 1;
        if(parkFactorEffect < 0) {
            parkFactorEffect = parkFactorEffect * 2;
        }
        parkFactorEffect = parkFactorEffect * constants.parkFactorMultiplier;
        styleSum += 10;
        styleSum = styleSum / 20.0;
        styleSum += parkFactorEffect;
        while(totalChange != maxChange) {
            double rng = generator.nextDouble();
            if(increase && rng < styleSum) {
                totalChange++;
            }
            else if(!increase && rng > styleSum) {
                totalChange++;
            }
            else {
                break;
            }
        }

        // Apply changes to score
        if(increase) {
            for(int i = 0; i < totalChange; i++) {
                int roadInning = generator.nextInt(constants.numInnings);
                int homeInning;
                if(!home.homeBatsInLastInning) {
                    homeInning = generator.nextInt(constants.numInnings - 1);
                }
                else {
                    homeInning = generator.nextInt(constants.numInnings);
                }
                road.score[roadInning]++;
                home.score[homeInning]++;
            }
        }
        else {
            // Road team's score = to number of runs to remove
            if(road.getTotalScore() == totalChange) {
                for(int i = 0; i < road.numInnings; i++) {
                    road.score[i] = 0;
                }
                if(road.numInnings > constants.numInnings) {
                    int hRunsRemoved = 0;
                    for(int i = 0; i < home.numInnings - 1; i++) {
                        hRunsRemoved += home.score[i];
                        home.score[i] = 0;
                    }
                    while(hRunsRemoved != totalChange) {
                        home.score[home.numInnings - 1]--;
                        hRunsRemoved++;
                    }
                }
                else {
                    int marginOfVictory = home.getTotalScore() - totalChange;
                    int hBaseline = home.getTotalScore();
                    int hRuns[] = new int[hBaseline];
                    boolean hRunsRemoved[] = new boolean[hBaseline];
                    int cur = 0;
                    for(int i = 0; i < home.numInnings ; i++) {
                        for(int j = 0; j < home.score[i]; j++) {
                            hRuns[cur] = i;
                            cur++;
                        }
                    }
                    for(int i = 0; i < totalChange; i++) {
                        int rng = generator.nextInt(hBaseline);
                        while(hRunsRemoved[rng]) {
                            rng = generator.nextInt(hBaseline);
                        }
                        while(home.score[constants.numInnings - 1] == marginOfVictory && hRuns[rng] == constants.numInnings - 1) {
                            rng = generator.nextInt(hBaseline);
                            while(hRunsRemoved[rng]) {
                                rng = generator.nextInt(hBaseline);
                            }
                        }
                        home.score[hRuns[rng]]--;
                        hRunsRemoved[rng] = true;
                    }
                }
            }
            // Home team's score equal to number of runs to remove
            else if(home.getTotalScore() == totalChange) {
                for(int i = 0; i < home.numInnings; i++) {
                    home.score[i] = 0;
                }
                if(home.numInnings > constants.numInnings) {
                    int rRunsRemoved = 0;
                    for(int i = 0; i < road.numInnings - 1; i++) {
                        rRunsRemoved += road.score[i];
                        road.score[i] = 0;
                    }
                    while(rRunsRemoved != totalChange) {
                        road.score[road.numInnings - 1]--;
                        rRunsRemoved++;
                    }
                }
                else {
                    int rBaseline = road.getTotalScore();
                    int rRuns[] = new int[rBaseline];
                    boolean rRunsRemoved[] = new boolean[rBaseline];
                    int cur = 0;
                    for(int i = 0; i < road.numInnings ; i++) {
                        for(int j = 0; j < road.score[i]; j++) {
                            rRuns[cur] = i;
                            cur++;
                        }
                    }
                    for(int i = 0; i < totalChange; i++) {
                        int rng = generator.nextInt(rBaseline);
                        while(rRunsRemoved[rng]) {
                            rng = generator.nextInt(rBaseline);
                        }
                        road.score[rRuns[rng]]--;
                        rRunsRemoved[rng] = true;
                    }
                }
            }
            else {
                int hBaseline = home.getTotalScore();
                int rBaseline = road.getTotalScore();
                int hRuns[] = new int[hBaseline];
                boolean hRunsRemoved[] = new boolean[hBaseline];
                int rRuns[] = new int[rBaseline];
                boolean rRunsRemoved[] = new boolean[rBaseline];
                int cur = 0;
                for(int i = 0; i < road.numInnings ; i++) {
                    for(int j = 0; j < road.score[i]; j++) {
                        rRuns[cur] = i;
                        cur++;
                    }
                }
                cur = 0;
                for (int i = 0; i < home.numInnings; i++) {
                    for (int j = 0; j < home.score[i]; j++) {
                        hRuns[cur] = i;
                        cur++;
                    }
                }
                for(int k = 0; k < totalChange; k++) {
                    int hRNG = generator.nextInt(hBaseline);
                    while (hRunsRemoved[hRNG] || (hRuns[hRNG] > constants.numInnings - 1 && road.score[hRuns[hRNG]] == 0) || (hRuns[hRNG] == constants.numInnings - 1 && home.score[constants.numInnings - 1] == 1 && (home.numInnings == constants.numInnings || hBaseline > rBaseline))) {
                        hRNG = generator.nextInt(hBaseline);
                    }
                    if (hRuns[hRNG] > constants.numInnings - 1) {
                        road.score[hRuns[hRNG]]--;
                        home.score[hRuns[hRNG]]--;
                        hRunsRemoved[hRNG] = true;
                        for (int i = 0; i < rRuns.length; i++) {
                            if (rRuns[i] == hRuns[hRNG]) {
                                hRunsRemoved[i] = true;
                                break;
                            }
                        }
                        continue;
                    }
                    home.score[hRuns[hRNG]]--;
                    hRunsRemoved[hRNG] = true;
                    int rRNG = generator.nextInt(rBaseline);
                    while(rRuns[rRNG] > constants.numInnings - 1 || rRunsRemoved[rRNG]) {
                        rRNG = generator.nextInt(rBaseline);
                    }
                    road.score[rRuns[rRNG]]--;
                    rRunsRemoved[rRNG] = true;
                }
            }
        }
    }

    private static void scorinateGameday(ArrayList<Team> teams, int seriesLength, boolean  homeAndAway, boolean rotateHomeAndAway) {
        while (seriesLength < 1) {
            Scanner readInput = new Scanner(System.in);
            System.out.println("Invalid length. You must enter a length of at least 1");
            seriesLength = Integer.valueOf(readInput.nextLine());
        }
        PrintWriter results = null;
        PrintWriter linescores = null;
        try {
            results = new PrintWriter((new FileOutputStream("results.txt", true)));
            linescores = new PrintWriter((new FileOutputStream("linescores.txt", true)));
            results.println("");
            linescores.println("-----------------------------------------------------------------------------------------\n");
            for (int i = 0; i < teams.size() - 1; i += 2) {
                if(rotateHomeAndAway) {
                    for (int j = 1; j <= seriesLength; j++) {
                        Team road = teams.get(i);
                        Team home = teams.get(i + 1);
                        scorinate(road, home);
                        printScore(road, home, results, linescores);
                        if (homeAndAway) {
                            home.resetScore(constants.numInnings);
                            road.resetScore(constants.numInnings);
                            scorinate(home, road);
                            printScore(home, road, results, linescores);
                        }
                        home.resetScore(constants.numInnings);
                        road.resetScore(constants.numInnings);
                    }
                }
                else {
                    Team road = teams.get(i);
                    Team home = teams.get(i + 1);
                    for(int j = 1; j <= seriesLength; j++) {
                        scorinate(road, home);
                        printScore(road, home, results, linescores);
                        home.resetScore(constants.numInnings);
                        road.resetScore(constants.numInnings);
                    }
                    if(homeAndAway) {
                        for(int j = 1; j <= seriesLength; j++) {
                            scorinate(home, road);
                            printScore(home, road, results, linescores);
                            home.resetScore(constants.numInnings);
                            road.resetScore(constants.numInnings);
                        }
                    }
                }
            }
            System.out.println("Scorination Complete.");
        } catch (FileNotFoundException e) {
            System.err.println("Could not print to file");
        } finally {
            linescores.close();
            results.close();
        }
    }

    private static void scorinateRoundRobin(ArrayList<Team> teams, int roundRobins, int seriesLength) {
        ArrayList<ArrayList<Team>> divisions = getDivisions(teams);
        PrintWriter results = null;
        PrintWriter linescores = null;
        try {
            results = new PrintWriter((new FileOutputStream("results.txt", true)));
            linescores = new PrintWriter((new FileOutputStream("linescores.txt", true)));
            for (ArrayList<Team> divisionTeams : divisions) {
                results.println(divisionTeams.get(0).division + ":");
                results.println();
                linescores.println(divisionTeams.get(0).division + ":");
                linescores.println();
                boolean oddNumTeams = (divisionTeams.size() % 2) == 1;
                for (int i = 0; i < roundRobins; i++) {
                    int numMatchdays = divisionTeams.size();
                    int matchesPerDay = divisionTeams.size() / 2;
                    if(!oddNumTeams) {
                        numMatchdays--;
                    }
                    else {
                        matchesPerDay++;
                    }
                    for(int j = 0; j < numMatchdays; j++) {
                        boolean[] alreadyPlayed = new boolean[divisionTeams.size()];
                        int numMatches = 0;
                        while(numMatches < matchesPerDay) {
                            Team home = null;
                            Team road = null;
                            int first = 0;
                            while(alreadyPlayed[first]) {
                                first++;
                            }
                            int second = ((((matchesPerDay * 2) - 1) - first + j) % ((matchesPerDay * 2) - 1));
                            if(first == second) {
                                second = (matchesPerDay * 2) - 1;
                            }
                            if(oddNumTeams && ((second == (matchesPerDay * 2) - 1))) {
                                // First Team has a bye
                            }
                            else {
                                if(i % 2 == 0) {
                                    if(second == (matchesPerDay * 2)) {
                                        if(first <= matchesPerDay) {
                                            road = divisionTeams.get(second);
                                            home = divisionTeams.get(first);
                                        }
                                        else {
                                            road = divisionTeams.get(first);
                                            home = divisionTeams.get(second);
                                        }
                                    }
                                    else if(j == 0) {
                                        road = divisionTeams.get(first);
                                        home = divisionTeams.get(second);
                                    }
                                    else if((first % 2) != (second % 2)) {
                                        road = divisionTeams.get(first);
                                        home = divisionTeams.get(second);
                                    }
                                    else {
                                        road = divisionTeams.get(second);
                                        home = divisionTeams.get(first);
                                    }
                                }
                                else {
                                    if(second == (matchesPerDay * 2)) {
                                        if(first <= matchesPerDay) {
                                            home = divisionTeams.get(second);
                                            road = divisionTeams.get(first);
                                        }
                                        else {
                                            home = divisionTeams.get(first);
                                            road = divisionTeams.get(second);
                                        }
                                    }
                                    else if(j == 0) {
                                        home = divisionTeams.get(first);
                                        road = divisionTeams.get(second);
                                    }
                                    else if((first % 2) != (second % 2)) {
                                        home = divisionTeams.get(first);
                                        road = divisionTeams.get(second);
                                    }
                                    else {
                                        home = divisionTeams.get(second);
                                        road = divisionTeams.get(first);
                                    }
                                }
                            }
                            for(int k = 0; k < seriesLength; k++) {
                                scorinate(road, home);
                                printScore(road, home, results, linescores);
                                home.resetScore(constants.numInnings);
                                road.resetScore(constants.numInnings);
                            }
                            alreadyPlayed[first] = true;
                            alreadyPlayed[second] = true;
                            numMatches++;
                        }
                    }
                }
                results.println();
            }
        }catch (FileNotFoundException e) {
            System.err.println("Could not print to file");
        } finally {
            linescores.close();
            results.close();
        }
    }

    public static void scorinateRoundRobinMatchday(ArrayList<Team> teams, int seriesLength, int matchday) {
        ArrayList<ArrayList<Team>> divisions = getDivisions(teams);
        PrintWriter results = null;
        PrintWriter linescores = null;
        try {
            results = new PrintWriter((new FileOutputStream("results.txt", true)));
            linescores = new PrintWriter((new FileOutputStream("linescores.txt", true)));
            for (ArrayList<Team> divisionTeams : divisions) {
                results.println(divisionTeams.get(0).division + ":");
                results.println();
                linescores.println(divisionTeams.get(0).division + ":");
                linescores.println();
                boolean oddNumTeams = (divisionTeams.size() % 2) == 1;
                    int numMatchdays = divisionTeams.size();
                    int matchesPerDay = divisionTeams.size() / 2;
                    if(!oddNumTeams) {
                        numMatchdays--;
                    }
                    else {
                        matchesPerDay++;
                    }
                        boolean[] alreadyPlayed = new boolean[divisionTeams.size()];
                        int numMatches = 0;
                        while(numMatches < matchesPerDay) {
                            Team home = null;
                            Team road = null;
                            int first = 0;
                            while(alreadyPlayed[first]) {
                                first++;
                            }
                            int second = ((((matchesPerDay * 2) - 1) - first + (matchday % numMatchdays)) % ((matchesPerDay * 2) - 1));
                            if(first == second) {
                                second = (matchesPerDay * 2) - 1;
                            }
                            if(oddNumTeams && ((second == (matchesPerDay * 2) - 1))) {
                                // First Team has a bye
                                alreadyPlayed[first] = true;
                                numMatches++;
                            }
                            else {
                                if(matchday % (numMatchdays * 2) < numMatchdays) {
                                    if(second == (matchesPerDay * 2)) {
                                        if(first <= matchesPerDay) {
                                            road = divisionTeams.get(second);
                                            home = divisionTeams.get(first);
                                        }
                                        else {
                                            road = divisionTeams.get(first);
                                            home = divisionTeams.get(second);
                                        }
                                    }
                                    else if((matchday % numMatchdays) == 0) {
                                        road = divisionTeams.get(first);
                                        home = divisionTeams.get(second);
                                    }
                                    else if((first % 2) != (second % 2)) {
                                        road = divisionTeams.get(first);
                                        home = divisionTeams.get(second);
                                    }
                                    else {
                                        road = divisionTeams.get(second);
                                        home = divisionTeams.get(first);
                                    }
                                }
                                else {
                                    if(second == (matchesPerDay * 2)) {
                                        if(first <= matchesPerDay) {
                                            home = divisionTeams.get(second);
                                            road = divisionTeams.get(first);
                                        }
                                        else {
                                            home = divisionTeams.get(first);
                                            road = divisionTeams.get(second);
                                        }
                                    }
                                    else if((matchday % numMatchdays) == 0) {
                                        home = divisionTeams.get(first);
                                        road = divisionTeams.get(second);
                                    }
                                    else if((first % 2) != (second % 2)) {
                                        home = divisionTeams.get(first);
                                        road = divisionTeams.get(second);
                                    }
                                    else {
                                        home = divisionTeams.get(second);
                                        road = divisionTeams.get(first);
                                    }
                                }
                                for(int k = 0; k < seriesLength; k++) {
                                    scorinate(road, home);
                                    printScore(road, home, results, linescores);
                                    home.resetScore(constants.numInnings);
                                    road.resetScore(constants.numInnings);
                                }
                                alreadyPlayed[first] = true;
                                alreadyPlayed[second] = true;
                                numMatches++;
                            }
                        }
                results.println();
            }
        }catch (FileNotFoundException e) {
            System.err.println("Could not print to file");
        } finally {
            linescores.close();
            results.close();
        }
    }
    public static void printScore(Team road, Team home, PrintWriter results, PrintWriter linescores) {
        // Print Score to Files
        results.println(road.name + " " + road.getTotalScore() + "-" + home.getTotalScore() + " " + home.name);
        //System.out.println(road.name + " " + road.getTotalScore() + "-" + home.getTotalScore() + " " + home.name);
        String head = "Team Name ";
        String rLine = road.name + " ";
        String hLine = home.name + " ";
        while(hLine.length() < rLine.length()) {
            hLine += " ";
        }
        while(rLine.length() < hLine.length()) {
            rLine += " ";
        }
        while(head.length() < rLine.length()) {
            head += " ";
        }
        while(rLine.length() < head.length()) {
            rLine += " ";
            hLine += " ";
        }
        for(int k = 1; k <= road.numInnings; k++) {
            if(k < 10) {
                head += " " + k + " ";
            }
            else {
                head += k + " ";
            }
            int rScore = road.score[k - 1];
            int hScore = home.score[k - 1];
            if(rScore < 10) {
                rLine += " ";
                rLine += rScore;
                rLine += " ";
            }
            else {
                rLine += rScore;
                rLine += " ";
            }
            if (k == home.numInnings && !home.homeBatsInLastInning) {
                hLine += " X ";
            }
            else if(hScore < 10) {
                hLine += " ";
                hLine += hScore;
                hLine += " ";
            }
            else {
                hLine += hScore;
                hLine += " ";
            }
        }
        head += "Total";
        hLine += "  ";
        rLine += "  ";
        hLine += home.getTotalScore();
        rLine += road.getTotalScore();
        linescores.println(head);
        linescores.println(rLine);
        linescores.println(hLine);
        linescores.println("");
    }

    private static ArrayList<ArrayList<Team>> getDivisions(ArrayList<Team> teams) {
        ArrayList<ArrayList<Team>> divisions = new ArrayList<>();
        String currentDivisionName = teams.get(0).division;
        ArrayList<Team> currentDivision = new ArrayList<>();
        for(int i = 0; i < teams.size(); i++) {
            Team currentTeam = teams.get(i);
            if(!currentTeam.division.equals(currentDivisionName)) {
                divisions.add(currentDivision);
                currentDivision = new ArrayList<>();
                currentDivisionName = currentTeam.division;
            }
            currentDivision.add(currentTeam);
        }
        divisions.add(currentDivision);
        return divisions;
    }

    // Calculates the poisson probability that x = 0 given a certain number of mean successes (runsConst).
    private static double determineOutProbability(double runsConst) {
        return Math.pow(Math.E, -1 * runsConst);
    }
}

class Const {
    double runsConst;
    double lnmax;
    double maxRunVariance;
    int maxStyleChange;
    double styleMultiplier;
    double parkFactorMultiplier;
    double extraInningRunsConst;
    int numInnings;
    double homeFieldAdvantage;
    public Const() {
        runsConst = 0.4;
        lnmax = 5;
        maxRunVariance = 0.1;
        maxStyleChange = 6;
        styleMultiplier = 0.5;
        parkFactorMultiplier = 0.2;
        extraInningRunsConst = -1;
        numInnings = 9;
        homeFieldAdvantage = 0.005;
    }

    public Const(double runsConst, double lnmax, double maxRunVariance, int maxStyleChange, double styleMultiplier, double parkFactorMultiplier, double extraInningRunsConst, int numInnings, double homeFieldAdvantage) {
        this.runsConst = runsConst;
        this.lnmax = lnmax;
        this.maxRunVariance = maxRunVariance;
        this.maxStyleChange = maxStyleChange;
        this.styleMultiplier = styleMultiplier;
        this.parkFactorMultiplier = parkFactorMultiplier;
        this.extraInningRunsConst = extraInningRunsConst;
        this.numInnings = numInnings;
        this.homeFieldAdvantage = homeFieldAdvantage;
    }
}