Make sure you read this file carefully before running Baseinator and follow all instructions exactly.  In order for Baseinator to run, you must have the input files set up properly with the correct names. If these files do not exist or are set up incorrectly, Baseinator may return unpredictable results or even be unable to scorinate anything.

-------
Running Baseinator
-------

To run Baseinator, you must have the current version of Java installed on your computer. On Windows, simply click Baseinator.bat and Baseinator should run in a command line. On other operating systems, first try clicking Baseinator.jar. If this does not work, then open a command line, cd into the correct directory and use the command "java -jar Baseinator.jar" to run Baseinator.

Once you have Baseinator up, it will display a menu providing 10 different options (as of version 1.3). To select an option, enter the number that appears before the ). The options are:

1) Scorinate Single Gameday

This option scorinates a single gameday matching every two consecutive teams (based on the order that they appear in teams.txt) against one another. For each pair of teams, the team listed first will be the road team and the team listed second will be the home team.

2) Scorinate Home and Away

This option scorinates 2 gamedays matching every two consecutive teams (based on the order that they appear in teams.txt) against one another. For the first gameday, the team listed first in each pair of teams will be the road team and the team listed second will be the home team. For the second gameday, this is reversed.

3) Scorinate 2 Game Series

This option scorinates the same matchups as in option 1, but it does so twice.

4) Scorinate 3 Game Series

This option is just like option 3, but it scorinates those games 3 times.

5) Scorinate X Home and Away Series

This is just like option 2, except you can enter any number larger than zero for X.

6) Scorinate X Game Series

This is just like options 3 and 4, but you get to pick how many times it repeats.

7) Scorinate X Round Robins

This option scorinates X round robins in a single go. Before specifying your X value, you must specify a series length. If you have 6 teams per division/group and you specify a 3 game series w/ 2 Round Robins, Baseinator will scorinate 30 games per team, with teams playing the same opponent for 3 games at a time. If you specify a 1 game series w/ 6 Round Robins, Baseinator will also scorinate 30 games per team with teams playing a different opponent every game.

8) Scorinate a Single Matchday of a Round Robin

This option is like option 7 but it only scorinates a single matchday of option 7. As in option 7, you need to specify the series length first. The difference here is that you enter a specific matchday next. Baseinator will automatically determine what the schedule is supposed to be on that matchday and scorinate it. If you enter 3 for the series length, each team will play 3 games. If you enter 1 for the series length, each team will play a single game.

9) Generate Tables

This option uses your results.txt file to generate tables for each division/group, which are saved to a tables.txt file.

WARNING: In cases where 3 or more teams have the same record, Baseinator may not apply HTH tiebreakers correctly. Please manually check all tiebreakers in such cases before advancing teams to the playoffs in a tournament.

WARNING: If you're going to be using the table generator, make sure you do not delete your results.txt file and be sure to make backups of the file in case you accidentally scorinate the wrong games while trying to scorinate a future matchday (alternatively, you can simply delete any non-canon results from the file to prevent them from showing up in tables).

0) Quit

This option quits Baseinator.

-------
Accessing Results
-------

Baseinator outputs results into two files. The "linescores.txt" file contains linescores for every game. The "results.txt" file contains results in the appropriate format for Xkoranate's table generator to allow for tables to be generated quickly, if needed.

-------
teams.txt
-------

This is the one text file that is absolutely required for Baseinator to function. This should consist of a number of lines, each of them including a team in the following format:

Team Name;Trigram;Skill Modifier;Style Modifier;Park Factor

The team name is, obviously, the name of the team. The trigram is only used (as of version 1.0) by bonus.txt, which is explained below. The skill modifier is a number between 0 and positive infinity that represents the strength of the team. Usually, the skill modifier should be the team's rank plus any RP and roster bonuses attained. The style modifier is a number between -5 and 5 that reflects whether the team plays in low-scoring games or high-scoring games (the higher the style mod, the higher the scores and vice versa). The park factor is a number between 50 and 200 that reflects whether the team's ballpark favors hitters or pitchers. A park factor of 100 is neutral. A park factor above 100 is a hitters park and a park factor below 100 is a pitchers park. The road team's park factor is ignored by the scorinator.

NOTE: For neutral site games, tournament hosts should replace the home team's park factor with the park factor of the ballpark that is hosting the game. If using option 2 or option 5, replace the park factors for both teams with the park factors of the stadium where the game will actually be played.

NOTE: Hosts may wish to limit the range of style modifiers and park factors (or reduce their effects via the relevant constants) as extreme modifiers, combined with an extreme park factor can have extreme effects.

Examples of correctly formatted teams are:

West Saintland;SNT;2.35;2.5;103
Free Republics;FFR;1.26;5;125
Ilyseum;ILY;0;-3.3;94
Nordernious;;0;0;100

NOTE: Trigrams do not have to consist of 3 letters but that is the general NS Sports convention as popularized by the NS Olympics and domestic soccer competitions.

WARNING: If you choose to leave the Trigram field blank, make sure to include two semi-colons between the Team Name and the Skill Modifier. Failure to do so could lead to the team's style mod being assigned as a skill modifier (if negative, that means a skill mod of 0).

A new feature in Baseinator 1.2 allows you to specify groups/divisions. This can be done by including a line like any of the following before the first team in the group:

Group 1:
RepublicSoft Group:
Eastern Division:

Once Baseinator sees a line like the above, it will add teams to that division until you specify another division.

-------
bonus.txt
-------

The bonus.txt file is a fast way to apply roster bonuses and roleplay bonuses in tournaments where nations usually enter more than 1 team. The format for each line is as follows:

Trigram;Bonus

When Baseinator reads this file, it checks each team to determine if its trigram is in this file. If the trigrams match, the bonus amount is added to the team's skill modifier. If they don't match, the bonus is not applied to that team.

NOTE: If you enter more than 1 bonus for the same trigram, all of them will be applied.

An example of a correctly formatted bonus line is:

SNT;1.234

NOTE: For tournaments like the World Baseball Classic where each nation generally enters a single team, I would recommend just adding bonuses directly to the skill modifiers but you could definitely use bonus.txt for those tournaments if you specified trigrams for each nation.

-------
constants.txt
-------

The other major input file for Baseinator is constants.txt. This file is not exactly easy to understand by looking at it but the format is:

runsConst lnmax maxRunVariance maxStyleChange styleMultiplier parkFactorMultiplier extraInningRunsConst numInnings homeFieldAdvantage

NOTE: These constants should be placed on a single line with a space in between each one.

WARNING: All constants must be numbers and maxStyleChange must be a whole number (integer), not a decimal number.

Descriptions of the various constants follow:

runsConst - This sets the base probability of a run being scored in an inning as opposed to an out. A higher value will increase scoring. A lower value will decrease scoring.

lnmax - This number sets the upper bound for ln(ratio * e) and thus the maximum difference between skill modifiers that Baseinator will recognize. The default value of 8 sets the maximum ratio of higher skill modifier to lower skill modifier at approximately 1096.6. Raising it will increase the maximum ratio (lowering randomness for stronger teams) while lowering it will decrease the maximum ratio (increasing randomness for stronger teams).

maxRunVariance - This number sets the maximum amount that can be added or subtracted to a team's run probability based on ratio of ranks. Raising this value will lower randomness across the board while lowering it will raise randomness across the board.

maxStyleChange - This number, which is one of just 2 constants that must be a whole number (integer), represents the maximum number of runs that style modifiers and park factors can add to or subtract from the score of both teams. If one or both teams scored less than this number, however, Baseinator cannot reduce the winning team's margin of victory nor reduce any team's score below 0. Raising this number will increase the effect of style mods while reducing it will decrease their effect. To turn off style mod effects entirely, just set this constant to 0.

styleMultiplier - Before calculating the number of runs to add or subtract, the style modifier is multiplied by this number, which should be a decimal number between 0 and 1. A higher number will increase the effect of style mods while a lower number will do the opposite.

parkFactorMultiplier - This number reflects the effectiveness of the park factor. Like the styleMultiplier, it should be a decimal number between 0 and 1. This represents the maximum percentage that the home team's park factor can increase or decrease the sum of the style mods. A higher number will increase the effect of park factors while a smaller number will decrease its effect.

extraInningRunsConst - This constant is designed to allow tournament hosts to apply the runners start on base in extra innings rules by increasing the probability of scoring runs. It can be disabled by setting it to a negative value such as the default of -1. If set to a positive value, it replaces runsConst during extra innings.

numInnings - This constant allows for the number of innings in a regulation game to be quickly changed. Typical values that you may wish to use are 6 (Little League), 7 (softball) or 9 (baseball). Obviously, this number must be a whole number (integer) as you cannot play a partial inning.

homeFieldAdvantage - This constant adds a set amount of run variance between the home team and the road team independently of maxRunVariance. A larger number raises home field advantage. A smaller number lowers it. Setting it to 0.0 will disable it. Setting it to a negative value will create a home field disadvantage.

NOTE: The combined style modifier/park factor effect is already fairly high in the default constants. If both teams have +5 modifiers and the home team has a 200 park factor (or if both teams have -5 modifiers and the home team has a 50 park factor), the style effect will be at 95% of the max. If you wish to increase the effect of style mods, you may want to increase maxStyleChange first.

NOTE: The default constants produce approximately 9 total runs per game on neutral style modifiers/park factors. If both teams have the same extreme style mods, add or subtract approximately 4 runs per game at a neutral park. Expect much larger fluctuations if the park factors and/or style mods are extreme.

-------
tiebreakers.txt
-------

The tiebreakers.txt file allows you to set a list of tiebreakers for the table generator. Each tiebreaker must be listed on a separate line with its name spelled exactly as it appears below. Baseinator 1.2 supports the following tiebreakers:

HTHRec - Head to Head Record
HTHRunDiff - Head to Head Run Differential
HTHRunsFor - Head to Head Runs For
HTHRunsAgainst - Head to Head Runs Against
RunDiff - Overall Run Differential
RunsFor - Overall Runs For
RunsAgainst - Overall Runs Against

-------
How Baseinator Works
-------

First, Baseinator determines the ratio between the skill modifiers of the two teams. Then, it modifies the run probabilities as follows, depending upon the case:

Case 1: Both teams have equal skill modifiers. Both receive equal run probabilities (equal to runsConst).
Case 2: One team has a skill modifier of zero. The other has a skill modifier that is not zero. In this case, maxRunVariance is added to the stronger team's run probability and subtracted from the weaker's run probability.
Case 3: Both teams have skill modifiers that aren't equal and aren't zero. In this case, a multiplier is calculated using the formula ln(higherskill/lowerskill * e)/lnmax. This multiplier is then multiplied times maxRunVariance and the result is added to the stronger team's run probability and subtracted from the weaker's.

NOTE: If the multiplier is greater than 1.0 (i.e. the ln is greater than lnmax), the multiplier is set to 1.0 before it is multiplied by maxRunVariance, making Case 3 functionally equivalent to Case 2.

Once these probabilities are calculated, a formula equivalent to finding the Poisson probability for x = 0 is applied to both run probabilities to determine the scorination ranges.

Once these ranges are set, the scorinator simulates a baseball game. During each inning, a random number is generated. Depending on the random number, the team that is batting either scores a run or makes an out. If the team scores a run, the cycle repeats. If they make an out, the scorinator moves on to the next half-inning. This continues until the scorinator reaches the bottom of the 9th.

At the start of the bottom of the 9th, Baseinator checks if the home team is ahead. If the home team is ahead, the game concludes immediately. Otherwise, the home team is given the opportunity to win the game by a margin of up to 4 runs. Once the home team has a 4 run lead in the bottom of the 9th or makes an out in the bottom of the 9th, the scorination concludes.

At this point, Baseinator checks if the game is tied. If it is, then it checks if extraInningRunsConst is a positive number. If it is, then it figures the new probabilities based upon that number. At this point, the scorinator conducts additional innings under the same rules as the 9th inning until there is a winner.

After it finishes scorinating the game, Baseinator calculates the sum of the style mods and randomly determines whether to increase or decrease the score. After this decision is made, the style mods are adjusted based upon styleMultiplier and the park factor is applied. It uses this new number as a probability to calculate how many runs to add or subtract. It keeps adding to the total until the random number is out of range or the total number of runs to be added/subtracted is equal to maxStyleChange, whichever happens first. Once it has determined how many runs to add or subtract, Baseinator randomly determines which innings to add runs to or subtract runs from, while respecting various constraints to ensure that the scoreline remains possible under the rules of baseball.

WARNING: Should Baseinator produce an impossible linescore, that should be reported to me immediately because that is evidence of a bug within the style modifier/park factor code. The sooner I am aware that the code contains such a bug, the sooner I can release a new version that fixes it.

-------
License
-------

Baseinator is Copyright 2018-2019 to the NationStates.net user behind the nations Saintland, Free Republics, Nordernious, Falatulu and Ilyseum (amongst others).  Baseinator is open-source software, licensed to all who download it for any non-commercial use.  Full permission is granted to modify or re-use the source code of this program for non-commercial purposes, so long as proper credit is given. Permission is also granted to include code from this program, with proper credit, as part of an open-source program licensed under the GNU's General Public License or any GNU-approved variant of that license even though such licenses permit commercial use. Full permission is also granted to redistribute this program as long as it is distributed with this readme file intact and is distributed at no cost to the end user.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.